<?php

echo"
	<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
	<html  xmlns='http://www.w3.org/1999/xhtml'>
		<head>
			<title>Indo Swiss Medicare Product ~ www.ismpl.com</title>
			<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
			<meta http-equiv='X-UA-Compatible' content='IE=edge'>
			<meta name='viewport' content='width=device-width, initial-scale=1'>
			
			<link rel='icon' type='icon' href='".base_url("assets/icon/icon.png")."'/>
			<link rel='stylesheet' type='text/css' href='".base_url("assets/css/style.css")."'>
			<link rel='stylesheet' type='text/css' href='".base_url("assets/css/bootstrap.css")."'>
			
			<script>var base_url = '".base_url()."';</script>
			<script src='".base_url("assets/jLib/jQuery/jquery-1.11.1.min.js")."'></script>
			<script src='".base_url("assets/jLib/jBootstrap/bootstrap.js")."'></script>
			<script src='".base_url("assets/jLib/jSlider/jSlider.min.js")."'></script>
			<script src='".base_url("assets/jController/CtrlSystem.js")."'></script>
			<script src='".base_url("assets/jController/v1/CtrlContact.js")."'></script>
		</head>
	";
?>