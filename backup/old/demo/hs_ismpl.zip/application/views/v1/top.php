<?php

echo"
	<body style='background:#efefef;'>
		<div class='header_default' align='center'>
			<div class='content' align='left'>
				<table class='right'>
					<tr valign='center'>
						<td>For International Enquiry No. +62-82225335105</td>
						<td>&nbsp;&nbsp;|&nbsp;&nbsp;</td>
						<td><img src='".base_url("assets/icon/icon_mail.png")."'/></td>
						<td>&nbsp;neeraj@ismpl.com</td>
					</tr>
				</table>
				<img src='".base_url("assets/image/logo.png")."' height='70px'>
			</div>
		</div>
";