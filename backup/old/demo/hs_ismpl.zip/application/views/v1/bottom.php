<?php

echo"
	<div class='footer_default' align='center'>
			<div class='content' align='left'>
				<div style='float:left;margin-right:50px;height:250px;'>
					<img src='".base_url("assets/image/icon.png")."' height='80px'>
				</div>
				<ul>
					<li>
						<b style='font-size:16px;font-family:verdana;display:block;margin-bottom:10px;'>Regd. Office :-</b>
						<b style='font-size:14px;'>Indo Swiss Medicare Products</b><br>
						5/72, Vikas Nagar, Lucknow, <br>
						U.P - 226022<br>
						India<br><br>
						
						Tech Sales Director :<br>
						<b>Neeraj Srivastava</b><br>
						Ph : +62-82225335105
					</li>
					<li style='max-width:290px!important;'>
						<b style='font-size:16px;font-family:verdana;display:block;margin-bottom:10px;'>Indonesia Office :-</b>
						<b style='font-size:14px;'>Indo Swiss Medicare Products</b><br>
						Jl. Solo - Sragen Km 9.5, Palur,<br>
						Karanganyar, Solo - 57771<br>
						Indonesia<br><br>
						
						Sales Rep. :<br>
						<b>Ms. Armalita</b><br>
						Ph : +62-271-821102 | Fax : +62-271-821360<br>
					</li>
					<li>
						<b style='font-size:16px;font-family:verdana;display:block;margin-bottom:10px;'>Vietnam Office :-</b>
						<b style='font-size:14px;'>Indo Swiss Medicare Products</b><br>
						No. 10 Lane 4, Thaodien Ward, <br>
						District Two, Hochiminh City,<br>
						Vietnam<br><br>
						
						Resident Rep :<br>
						<b>Chinh Truong</b><br>
					</li>
					<li style='max-width:240px!important;min-height:50px!important;'>
						<b style='font-size:16px;font-family:verdana;display:block;margin-bottom:10px;'>Factories :-</b>
						<b style='font-size:14px;'>Unit - I</b><br>
						Plot No 149, First Floor,<br>
						Badli, Delhi - 110042<br>
						India
					</li>
					<li style='min-height:50px!important;'>
						<br><br>
						<b style='font-size:14px;'>Unit - II</b><br>
						4/21, Ajanta Compound,<br>
						Loni Road Industrial Area, Side-II,<br>
						Mohan Nagar, Gaziabad UP,<br>
						India
					</li>
				</ul>
			</div>
		</div>
		
		<div class='footer_default' align='center'>
			<div class='content' align='center' style='border-top:solid 1px #fff;padding:20px 0px 10px 0px;font-size:18px;font-family:tohama;'>
				<ol style='margin:0px;float:center;display:inline-block;'>
					<li style='float:left;list-style:none;width:360px;'>For International Enquiry No. +62-82225335105</li>
					<li style='float:left;list-style:none;width:250px;'>Email : neeraj@ismpl.com</li>
					<li style='float:left;list-style:none;width:250px;'>Website : www.ismpl.com</li>
				</ol>
			</div>
		</div>
		<br><br>
		<div align='center'>
			<div style='max-width:760px;font-size:10px;'>
				Copyright @2015 by Indo Swiss Medicare Products, All reserved.
			</div>
		</div>
		<br><br>
	</body>
</html>



<script>
	$('#slider').responsiveSlides({
        auto: true,
        pager: false,
        nav: false,
        speed: 600,
        maxwidth: window.screen.width,
        namespace: 'slider-item-'
    });
</script>
";

?>