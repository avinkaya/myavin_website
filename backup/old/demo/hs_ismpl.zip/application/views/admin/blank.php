<?php

echo"
      <div class='content-wrapper'>
        <section class='content-header'>
          <h1>
            Manage User
            <small>This pages for user management and privilage</small>
          </h1>
          <ol class='breadcrumb'>
            <li><a href='".base_url("admin")."'><i class='fa fa-dashboard'></i> Home</a></li>
			<li><a href='#'><i class='fa fa-dashboard'></i> Users</a></li>
            <li class='active'>Manage User</li>
          </ol>
        </section>

        <section class='content'>


        </section>
      </div>
";

?>