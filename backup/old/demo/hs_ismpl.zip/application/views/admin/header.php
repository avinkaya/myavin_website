<?php

echo"<!DOCTYPE html>

<html>
  <head>
    <meta charset='UTF-8'>
    <title>Indo Swiss Medicare Product Ltd | Administator</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link rel='stylesheet' href='".base_url("assets/admin/jLib/jBootstrap/css/bootstrap.min.css")."'>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css'>
    <link rel='stylesheet' href='".base_url("assets/admin/css/AdminLTE.min.css")."'>
    <link rel='stylesheet' href='".base_url("assets/admin/css/skins/skin-blue.min.css")."'>
	<link rel='stylesheet' href='".base_url("assets/admin/css/style_admin.css")."'>
	
	<script>var base_url = '".base_url()."';</script>
	<script src='".base_url("assets/admin/jLib/jQuery/jQuery-2.1.4.min.js")."'></script>
    <script src='".base_url("assets/admin/jLib/jBootstrap/js/bootstrap.min.js")."'></script>
    <script src='".base_url("assets/admin/js/app.min.js")."'></script>
	<script src='".base_url("assets/admin/jController/CtrlSystem.js")."'></script>
	<script src='".base_url("assets/admin/jController/CtrlUsers.js")."'></script>
	<script src='".base_url("assets/admin/jController/CtrlUnits.js")."'></script>
	<script src='".base_url("assets/admin/jController/CtrlCategories.js")."'></script>
	<script src='".base_url("assets/admin/jController/CtrlSubCategories.js")."'></script>
	<script src='".base_url("assets/admin/jController/CtrlProducts.js")."'></script>
	<script src='".base_url("assets/admin/jController/CtrlSliders.js")."'></script>
  </head>
  
  <body class='skin-blue sidebar-mini'>
    <div class='wrapper'>
  ";
?>