<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['public_key']   = '6LdMyOQSAAAAAC4X8cDpsLsVTBLYxazXQ2m679bL';
$config['private_key']  = '6LdMyOQSAAAAAN1hetn5Qqj1mwStASqhtZOPLf-S ';

?>
